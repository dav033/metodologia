"use client";

import type { ReactNode } from "react";
import { createContext, useContext, useMemo } from "react";
import type { ContactsAppContext } from "@/contact";
import type { LeadsAppContext } from "@/leads";
import type { ProjectTypesAppContext } from "@/projectType";
import type { CompanyAppContext } from "@/company";
import type { ReportsAppContext } from "@/reports";
import type { ProjectsAppContext } from "@/project";
import type { AnalyticsAppContext } from "@/analytics";
import type { QuickbooksAppContext } from "@/quickbooks";
import type { NotesAppContext } from "@/notes";
import type { UsersAppContext } from "@/features/users";
import type { TasksAppContext } from "@/tasks";
import type { NotificationsAppContext } from "@/notifications";
import {
  createContactsAppContext,
  createLeadsAppContext,
  createProjectTypesAppContext,
  createCompanyAppContext,
  createReportsAppContext,
  createProjectsAppContext,
  createAnalyticsAppContext,
  createQuickbooksAppContext,
  createNotesAppContext,
  createUsersAppContext,
  createTasksAppContext,
  createNotificationsAppContext,
} from "./factories";

type DiContextValue = {
  contactsApp: ContactsAppContext;
  leadsApp: LeadsAppContext;
  projectTypesApp: ProjectTypesAppContext;
  companyApp: CompanyAppContext;
  reportsApp: ReportsAppContext;
  projectsApp: ProjectsAppContext;
  analyticsApp: AnalyticsAppContext;
  quickbooksApp: QuickbooksAppContext;
  notesApp: NotesAppContext;
  usersApp: UsersAppContext;
  tasksApp: TasksAppContext;
  notificationsApp: NotificationsAppContext;
};

const DiContext = createContext<DiContextValue | null>(null);

type Props = {
  children: ReactNode;
};

export function DiProvider({ children }: Props) {
  const value = useMemo(() => ({
    contactsApp: createContactsAppContext(),
    leadsApp: createLeadsAppContext(),
    projectTypesApp: createProjectTypesAppContext(),
    companyApp: createCompanyAppContext(),
    reportsApp: createReportsAppContext(),
    projectsApp: createProjectsAppContext(),
    analyticsApp: createAnalyticsAppContext(),
    quickbooksApp: createQuickbooksAppContext(),
    notesApp: createNotesAppContext(),
    usersApp: createUsersAppContext(),
    tasksApp: createTasksAppContext(),
    notificationsApp: createNotificationsAppContext(),
  }), []);

  return <DiContext.Provider value={value}>{children}</DiContext.Provider>;
}

export function useContactsApp(): ContactsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useContactsApp must be used within DiProvider");
  }
  return context.contactsApp;
}

export function useLeadsApp(): LeadsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useLeadsApp must be used within DiProvider");
  }
  return context.leadsApp;
}

export function useProjectTypesApp(): ProjectTypesAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useProjectTypesApp must be used within DiProvider");
  }
  return context.projectTypesApp;
}

export function useCompanyApp(): CompanyAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useCompanyApp must be used within DiProvider");
  }
  return context.companyApp;
}

export function useReportsApp(): ReportsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useReportsApp must be used within DiProvider");
  }
  return context.reportsApp;
}

export function useProjectsApp(): ProjectsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useProjectsApp must be used within DiProvider");
  }
  return context.projectsApp;
}

export function useAnalyticsApp(): AnalyticsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useAnalyticsApp must be used within DiProvider");
  }
  return context.analyticsApp;
}

export function useQuickbooksApp(): QuickbooksAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useQuickbooksApp must be used within DiProvider");
  }
  return context.quickbooksApp;
}

export function useNotesApp(): NotesAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useNotesApp must be used within DiProvider");
  }
  return context.notesApp;
}

export function useUsersApp(): UsersAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useUsersApp must be used within DiProvider");
  }
  return context.usersApp;
}

export function useTasksApp(): TasksAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useTasksApp must be used within DiProvider");
  }
  return context.tasksApp;
}

export function useNotificationsApp(): NotificationsAppContext {
  const context = useContext(DiContext);
  if (!context) {
    throw new Error("useNotificationsApp must be used within DiProvider");
  }
  return context.notificationsApp;
}
