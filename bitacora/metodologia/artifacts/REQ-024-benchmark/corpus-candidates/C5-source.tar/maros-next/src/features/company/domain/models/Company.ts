export enum CompanyType {
  DESIGN = "DESIGN",
  HOA = "HOA",
  GENERAL_CONTRACTOR = "GENERAL_CONTRACTOR",
  SUPPLIER = "SUPPLIER",
  SUBCONTRACTOR = "SUBCONTRACTOR",
  OTHER = "OTHER",
}

export type CompanyId = number;

export interface Company {
  id: CompanyId;
  name: string;
  address?: string | undefined;
  addressLink?: string | undefined;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer: boolean;
  isClient: boolean;
  notes: string[];
  attachments?: string[];
  phone?: string | undefined;
  email?: string | undefined;
  submiz?: string | undefined;
}

export type CompanyDraft = Readonly<{
  name: string;
  address?: string | null | undefined;
  addressLink?: string | null | undefined;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer?: boolean | undefined;
  isClient?: boolean | undefined;
  notes?: string[] | null;
  attachments?: string[] | null;
  phone?: string | null | undefined;
  email?: string | null | undefined;
  submiz?: string | null | undefined;
}>;

export type CompanyPatch = Readonly<{
  name?: string | undefined;
  address?: string | null | undefined;
  addressLink?: string | null | undefined;
  type?: CompanyType | null | undefined;
  serviceId?: number | null | undefined;
  isCustomer?: boolean | undefined;
  isClient?: boolean | undefined;
  notes?: string[] | null | undefined;
  attachments?: string[] | null | undefined;
  phone?: string | null | undefined;
  email?: string | null | undefined;
  submiz?: string | null | undefined;
}>;

export interface CompanyPolicies {}
export interface CompanyPatchPolicies {}

export interface CompanyDetails {
  id: number;
  name: string;
  address?: string;
  addressLink?: string;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer: boolean;
  isClient: boolean;
  notes: string[];
  attachments?: string[];
  phone?: string;
  email?: string;
  submiz?: string;
  contacts?: Array<{
    id: number;
    name?: string;
    phone?: string;
    email?: string;
    address?: string;
    addressLink?: string;
    isCustomer: boolean;
    isClient: boolean;
    notes: string[];
  }>;
}
