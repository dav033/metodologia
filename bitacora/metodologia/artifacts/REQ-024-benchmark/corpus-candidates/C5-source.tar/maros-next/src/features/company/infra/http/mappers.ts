import {
  Company,
  CompanyDraft,
  CompanyPatch,
  CompanyType,
} from "../../domain/models";

export type ApiCompanyDTO = {
  id: number;
  name: string;
  address?: string | null;
  addressLink?: string | null;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer: boolean;
  isClient: boolean;
  notes?: string[] | null;
  attachments?: string[] | null;
  phone?: string | null;
  email?: string | null;
  submiz?: string | null;
};

export type CreateCompanyRequestDTO = {
  name: string;
  address?: string | null;
  addressLink?: string | null;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer: boolean;
  isClient: boolean;
  notes?: string[] | null;
  attachments?: string[] | null;
  phone?: string | null;
  email?: string | null;
  submiz?: string | null;
};

export type UpdateCompanyRequestDTO = {
  name: string;
  address?: string | null;
  addressLink?: string | null;
  type: CompanyType;
  serviceId?: number | null;
  isCustomer: boolean;
  isClient: boolean;
  notes?: string[] | null;
  attachments?: string[] | null;
  phone?: string | null;
  email?: string | null;
  submiz?: string | null;
};

export function mapCompanyFromApi(dto: ApiCompanyDTO): Company {
  let type = dto.type;
  if (!Object.values(CompanyType).includes(type as CompanyType)) {
    type = CompanyType.OTHER;
  }

  const normalizedName = typeof dto.name === "string" ? dto.name : "";
  
  return {
    id: dto.id,
    name: normalizedName,
    address: dto.address ?? undefined,
    addressLink: dto.addressLink ?? undefined,
    type: type as CompanyType,
    serviceId: dto.serviceId ?? undefined,
    isCustomer: dto.isCustomer,
    isClient: dto.isClient,
    notes: dto.notes ?? [],
    attachments: dto.attachments ?? [],
    phone: dto.phone ?? undefined,
    email: dto.email ?? undefined,
    submiz: dto.submiz ?? undefined,
  };
}

export function mapCompaniesFromApi(dtos: ApiCompanyDTO[]): Company[] {
  return dtos.map(mapCompanyFromApi);
}

export function mapCompanyDraftToCreateDTO(
  draft: CompanyDraft,
): CreateCompanyRequestDTO {
  return {
    name: draft.name,
    address: draft.address ?? null,
    addressLink: draft.addressLink ?? null,
    type: draft.type,
    serviceId: draft.serviceId ?? null,
    isCustomer: draft.isCustomer ?? false,
    isClient: draft.isClient ?? false,
    notes:
      draft.notes && draft.notes.length > 0
        ? draft.notes
        : null,
    attachments: draft.attachments ?? null,
    phone: draft.phone ?? null,
    email: draft.email ?? null,
    submiz: draft.submiz ?? null,
  };
}

export function mapCompanyPatchToUpdateDTO(
  patch: CompanyPatch,
): UpdateCompanyRequestDTO {
  const dto: any = {};
  
  if (patch.name !== undefined && patch.name !== null) {
    dto.name = patch.name;
  }
  if (patch.address !== undefined) {
    dto.address = patch.address;
  }
  if (patch.addressLink !== undefined) {
    dto.addressLink = patch.addressLink;
  }
  if (patch.type !== undefined) {
    dto.type = patch.type;
  }
  if (patch.serviceId !== undefined) {
    dto.serviceId = patch.serviceId;
  }
  if (patch.isCustomer !== undefined) {
    dto.isCustomer = patch.isCustomer;
  }
  if (patch.isClient !== undefined) {
    dto.isClient = patch.isClient;
  }
  if (patch.notes !== undefined) {
    dto.notes = patch.notes;
  }
  if (patch.attachments !== undefined) {
    dto.attachments = patch.attachments;
  }
  if (patch.phone !== undefined) {
    dto.phone = patch.phone;
  }
  if (patch.email !== undefined) {
    dto.email = patch.email;
  }
  if (patch.submiz !== undefined) {
    dto.submiz = patch.submiz;
  }
  
  return dto;
}

export type ApiCompanyServiceDTO = any;

export function mapCompanyServiceFromApi(dto: ApiCompanyServiceDTO) {
  return dto as any;
}

export function mapCompanyServicesFromApi(dtos: ApiCompanyServiceDTO[]) {
  return dtos.map(mapCompanyServiceFromApi);
}

export function mapCompanyServiceDraftToCreateDTO(draft: any) {
  return draft as any;
}

export function mapCompanyServicePatchToUpdateDTO(patch: any) {
  return patch as any;
}
