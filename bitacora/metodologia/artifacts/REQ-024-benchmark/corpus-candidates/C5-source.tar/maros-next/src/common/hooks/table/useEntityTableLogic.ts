"use client";

import { useCallback, useEffect, useState } from "react";
import React from "react";

/** Item del menú contextual de una fila de tabla. */
export interface ContextMenuItem {
  /** Texto visible del item. */
  label: string;
  /** Acción al hacer clic. No es necesario si el item tiene `subItems`. */
  onClick?: () => void;
  /** Variante visual: `"danger"` pinta el texto en rojo. */
  variant?: "default" | "danger";
  /** Icono (nombre string lucide/mdi o ReactNode). */
  icon?: string | React.ReactNode;
  /** Deshabilitado (no se puede hacer clic). */
  disabled?: boolean;
  /** Muestra un checkmark al final del item. */
  checked?: boolean;
  /** Renderiza un separador horizontal en lugar del item. */
  separator?: boolean;
  /** Subítems anidados para menú en cascada. */
  subItems?: ContextMenuItem[];
}

export interface UseEntityTableLogicOptions<T, TId = number> {
  items: T[] | undefined;
  onDelete?: (id: TId) => Promise<void>;
  onEdit?: (item: T) => void;
  getId?: (item: T) => TId;
  buildExtraMenuItems?: (item: T) => ContextMenuItem[];
}

export function useEntityTableLogic<T, TId = number>({
  items,
  onDelete,
  onEdit,
  getId = (item: any) => item.id,
  buildExtraMenuItems,
}: UseEntityTableLogicOptions<T, TId>) {
  // Sembrar con los items y no con [] importa para el render del servidor: ahí los
  // efectos no corren, así que arrancar vacío hacía que la página se enviara con el
  // estado "no hay nada" aunque el loader ya traía las filas, y solo se llenaba cuando
  // la hidratación terminaba. El efecto de abajo sigue encargándose de los cambios
  // posteriores.
  const [rows, setRows] = useState<T[]>(() => items ?? []);

  // Comparar solo los ids no alcanza: hay datos que llegan después del primer
  // render y se mezclan en las filas ya existentes (los montos de QuickBooks en
  // Projects, por ejemplo). Eso produce objetos nuevos con los mismos ids, y una
  // comparación por id los descartaba en silencio. Se comparan las referencias
  // de cada item: quien pase este array debe memoizarlo, o el efecto correría en
  // cada render.
  const areItemsEqual = useCallback((a: T[], b: T[]) => {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) return false;
    }
    return true;
  }, []);

  useEffect(() => {
    const newItems = items ?? [];
    setRows((prev) => (areItemsEqual(prev, newItems) ? prev : newItems));
  }, [items, areItemsEqual]);

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<T | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const openDeleteModal = useCallback((item: T) => {
    setItemToDelete(item);
    setDeleteError(null);
    setIsDeleteModalOpen(true);
  }, []);

  const closeDeleteModal = useCallback(() => {
    setIsDeleteModalOpen(false);
    setItemToDelete(null);
    setDeleteError(null);
  }, []);

  const confirmDelete = useCallback(async () => {
    if (!itemToDelete || !onDelete) return;
    const id = getId(itemToDelete);

    try {
      setIsDeleting(true);
      setDeleteError(null);
      await onDelete(id);
      setRows((prev) => prev.filter((row) => getId(row) !== id));
      closeDeleteModal();
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Failed to delete item";
      setDeleteError(msg);
    } finally {
      setIsDeleting(false);
    }
  }, [itemToDelete, onDelete, getId, closeDeleteModal]);

  const getContextMenuItems = useCallback(
    (row: T): ContextMenuItem[] => {
      const items: ContextMenuItem[] = [];

      if (onEdit) {
        items.push({
          label: "Edit",
          onClick: () => onEdit(row),
          icon: "lucide:edit",
        });
      }

      if (buildExtraMenuItems) {
        items.push(...buildExtraMenuItems(row));
      }

      if (onDelete) {
        items.push({
          label: "Delete",
          onClick: () => openDeleteModal(row),
          variant: "danger",
          icon: "lucide:trash",
        });
      }

      return items;
    },
    [onEdit, onDelete, openDeleteModal, buildExtraMenuItems]
  );

  return {
    rows,
    deleteModalProps: {
      isOpen: isDeleteModalOpen,
      onClose: closeDeleteModal,
      onConfirm: confirmDelete,
      itemToDelete,
      isDeleting,
      error: deleteError,
    },
    getContextMenuItems,
  };
}
