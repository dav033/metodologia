import type { LeadType } from "@/leads/domain";
import type { AnalyticsRepositoryPort } from "../../domain/ports";
import type { HttpClientLike } from "@/shared/infra/http";
import { optimizedApiClient } from "@/shared/infra/http";
import { analyticsEndpoints } from "./endpoints";
import {
  mapCostsBreakdown,
  mapExpensesSummary,
  mapLeadsPerMonth,
  mapFinancialSnapshot,
  mapOverview,
  mapPipeline,
  mapProjectHealth,
  mapProjectsStatus,
  mapBacklog,
  mapOutstandingBalances,
  mapProjectFinancials,
  mapQuickbooksParsedReport,
  mapRevenueTrend,
  mapTopClients,
} from "./mappers";
import type {
  BacklogItemResponse,
  CostsBreakdownResponse,
  ExpensesSummaryResponse,
  LeadsPerMonthPointResponse,
  FinancialSnapshotResponse,
  OutstandingBalanceItemResponse,
  OverviewResponse,
  ProjectFinancialItemResponse,
  PipelineBucketResponse,
  ProjectHealthResponse,
  ProjectsStatusBucketResponse,
  QuickbooksParsedReportResponse,
  RefreshResponse,
  RevenuePointResponse,
  TopClientResponse,
} from "./responses";

export class AnalyticsHttpRepository implements AnalyticsRepositoryPort {
  constructor(private readonly api: HttpClientLike = optimizedApiClient) {}

  async getOverview(params?: { from?: string; to?: string; leadType?: LeadType }) {
    const { data } = await this.api.get<OverviewResponse>(analyticsEndpoints.overview(), { params });
    return mapOverview(data);
  }

  async getPipeline(params?: { leadType?: LeadType }) {
    const { data } = await this.api.get<PipelineBucketResponse[]>(analyticsEndpoints.pipeline(), {
      params,
    });
    return mapPipeline(data);
  }

  async getProjectsStatus(params?: { leadType?: LeadType }) {
    const { data } = await this.api.get<ProjectsStatusBucketResponse[]>(
      analyticsEndpoints.projectsStatus(),
      { params },
    );
    return mapProjectsStatus(data);
  }

  async getFinancialSnapshot(params?: { leadType?: LeadType }) {
    const { data } = await this.api.get<FinancialSnapshotResponse>(
      analyticsEndpoints.financialSnapshot(),
      { params },
    );
    return mapFinancialSnapshot(data);
  }

  async getLeadsPerMonth(params?: { months?: number; from?: string; to?: string; leadType?: LeadType }) {
    const { data } = await this.api.get<LeadsPerMonthPointResponse[]>(
      analyticsEndpoints.leadsPerMonth(),
      {
        params: {
          months: params?.months ?? 12,
          from: params?.from,
          to: params?.to,
          leadType: params?.leadType,
        },
      },
    );
    return mapLeadsPerMonth(data);
  }

  async getRevenueTrend(params?: { months?: number; from?: string; to?: string; leadType?: LeadType }) {
    const months = params?.months ?? 12;
    const { data } = await this.api.get<RevenuePointResponse[]>(analyticsEndpoints.revenueTrend(), {
      params: {
        months,
        from: params?.from,
        to: params?.to,
        leadType: params?.leadType,
      },
    });
    return mapRevenueTrend(data);
  }

  async getTopClients(params?: { limit?: number; by?: "revenue" | "volume"; from?: string; to?: string; leadType?: LeadType }) {
    const { data } = await this.api.get<TopClientResponse[]>(analyticsEndpoints.topClients(), {
      params,
    });
    return mapTopClients(data);
  }

  async getOutstandingBalances(params?: { limit?: number; leadType?: LeadType }) {
    const { data } = await this.api.get<OutstandingBalanceItemResponse[]>(
      analyticsEndpoints.outstandingBalances(),
      { params },
    );
    return mapOutstandingBalances(data);
  }

  async getBacklog(params?: { limit?: number; leadType?: LeadType }) {
    const { data } = await this.api.get<BacklogItemResponse[]>(analyticsEndpoints.backlog(), {
      params,
    });
    return mapBacklog(data);
  }

  async getQuickbooksRevenueReport(params?: { from?: string; to?: string }) {
    const { data } = await this.api.get<QuickbooksParsedReportResponse>(
      analyticsEndpoints.quickbooksRevenueReport(),
      { params },
    );
    return mapQuickbooksParsedReport(data);
  }

  async getProjectFinancials(params?: { limit?: number; leadType?: LeadType }) {
    const { data } = await this.api.get<ProjectFinancialItemResponse[]>(
      analyticsEndpoints.projectFinancials(),
      { params },
    );
    return mapProjectFinancials(data);
  }

  async getProjectHealth(params?: { leadType?: LeadType }) {
    const { data } = await this.api.get<ProjectHealthResponse[]>(
      analyticsEndpoints.projectHealth(),
      { params },
    );
    return mapProjectHealth(data);
  }

  async getExpensesSummary(params?: {
    from?: string;
    to?: string;
    leadType?: LeadType;
  }) {
    const { data } = await this.api.get<ExpensesSummaryResponse>(
      analyticsEndpoints.expensesSummary(),
      { params },
    );
    return mapExpensesSummary(data);
  }

  async getCostsBreakdown(params?: {
    from?: string;
    to?: string;
    leadType?: LeadType;
  }) {
    const { data } = await this.api.get<CostsBreakdownResponse>(
      analyticsEndpoints.costsBreakdown(),
      { params },
    );
    return mapCostsBreakdown(data);
  }

  async refresh() {
    const { data } = await this.api.post<RefreshResponse>(analyticsEndpoints.refresh());
    return { ok: Boolean(data?.ok) };
  }
}
