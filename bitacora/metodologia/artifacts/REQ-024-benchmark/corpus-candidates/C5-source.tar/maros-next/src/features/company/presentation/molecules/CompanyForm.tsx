"use client";

import type { CompanyType, CompanyService } from "../../domain/models";
import type { Contact } from "@/contact";
import { Textarea } from "@/components/ui/textarea";

import {
  CompanyBasicFields,
  CompanyTypeFields,
  CompanyContactsSelector,
  CompanyCheckboxField,
  useCompanyFormHandlers,
} from "./form";

export type CompanyFormValue = {
  name: string;
  address: string;
  addressLink?: string;
  type: CompanyType | null;
  serviceId: number | null;
  isCustomer: boolean;
  isClient: boolean;
  contactIds: number[];
  notes: string[];
  note?: string;
  phone?: string;
  email?: string;
  submiz?: string;
};

export type CompanyFormProps = {
  value: CompanyFormValue;
  onChange: (value: CompanyFormValue) => void;
  disabled?: boolean;
  services?: CompanyService[];
  contacts?: Contact[];
  onCreateNewContact?: () => void;
};

export function CompanyForm({ value, onChange, disabled, services = [], contacts = [], onCreateNewContact }: CompanyFormProps) {
  const {
    handleTextChange,
    handleTypeChange,
    handleServiceChange,
    handleCustomerChange,
    handleClientChange,
    handleContactToggle,
    handleNoteChange,
  } = useCompanyFormHandlers(value, onChange);

  return (
    <div className="space-y-4">
      <div className="space-y-4">
        <CompanyBasicFields
          name={value.name}
          address={value.address}
          addressLink={value.addressLink}
          phone={value.phone}
          email={value.email}
          submiz={value.submiz}
          disabled={disabled}
          onNameChange={(event) => handleTextChange(event, "name")}
          onAddressChange={(address) => onChange({ ...value, address })}
          onAddressLinkChange={(addressLink) => onChange({ ...value, addressLink })}
          onLocationChange={({ address, link }) => onChange({ ...value, address, addressLink: link })}
          onPhoneChange={(phone) => onChange({ ...value, phone })}
          onEmailChange={(email) => onChange({ ...value, email })}
          onSubmizChange={(submiz) => onChange({ ...value, submiz })}
        />

        <CompanyTypeFields
          type={value.type}
          serviceId={value.serviceId}
          disabled={disabled}
          services={services}
          onTypeChange={handleTypeChange}
          onServiceChange={handleServiceChange}
        />

        <CompanyContactsSelector
          selectedContactIds={value.contactIds}
          contacts={contacts}
          disabled={disabled}
          onContactToggle={handleContactToggle}
          onCreateNewContact={onCreateNewContact}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-2">
          <CompanyCheckboxField
            id="company-is-customer"
            label="CUSTOMER"
            checked={value.isCustomer}
            disabled={disabled}
            onChange={handleCustomerChange}
          />
          <CompanyCheckboxField
            id="company-is-client"
            label="SUPPLIER"
            checked={value.isClient}
            disabled={disabled}
            onChange={handleClientChange}
          />
        </div>
        <Textarea
          value={value.note ?? ""}
          onChange={handleNoteChange}
          placeholder="Add a note (optional)"
          disabled={disabled}
          rows={2}
          className="border-line-strong"
        />
      </div>
    </div>
  );
}
