import { ApiError, GoogleGenAI, ThinkingLevel, type Content, type FunctionDeclaration, type Part } from "@google/genai";
import { conReintento } from "../retry";
import { bytesDeBase64, ErrorIA } from "../tipos";
import type { ChatPort, FragmentoChat, Herramienta, ImagenAdjunta, LlamadaHerramienta, Mensaje, PeticionChat, TurnoChat } from "../tipos";

type MetadatosUsoGemini = {
  promptTokenCount?: number;
  candidatesTokenCount?: number;
  cachedContentTokenCount?: number;
  thoughtsTokenCount?: number;
  toolUsePromptTokenCount?: number;
};

export function extraerUsoGemini(metadata: MetadatosUsoGemini | undefined): TurnoChat["uso"] {
  return {
    entrada: metadata?.promptTokenCount ?? 0,
    salida: metadata?.candidatesTokenCount ?? 0,
    cacheados: metadata?.cachedContentTokenCount ?? 0,
    pensamiento: metadata?.thoughtsTokenCount ?? 0,
    promptHerramientas: metadata?.toolUsePromptTokenCount ?? 0,
  };
}

/** Mismo default que tenía este adaptador dentro de demo-decoracion — se
 * conserva para no cambiar comportamiento; un consumidor nuevo lo overridea
 * con `opts.modelo` o la misma env var. */
const MODELO_POR_DEFECTO = process.env.GEMINI_CHAT_MODEL ?? "gemini-3.6-flash";

function herramientaADeclaracion(h: Herramienta): FunctionDeclaration {
  return {
    name: h.nombre,
    description: h.descripcion,
    parametersJsonSchema: h.esquema,
  };
}

/**
 * Agrupa mensajes "herramienta" consecutivos en un solo Content: Gemini
 * espera todas las functionResponse de un mismo turno juntas en un único
 * mensaje de rol "user".
 *
 * Fase 3.1: `historial` es el mismo array (mutado por referencia) durante
 * las hasta 10 vueltas de una sola ejecución del tool loop — `ejecutar.ts`
 * nunca clona los mensajes de usuario ya existentes, solo agrega mensajes
 * nuevos al final. Eso permite marcar cada `ImagenAdjunta` ya transmitida en
 * `imagenesEnviadas` (vive en el closure de `crearChatGemini`, una por
 * request) y, en vueltas siguientes, omitir su `inlineData` — el modelo
 * sigue viendo el texto `[IMAGEN_ID=...]` para referirse a ella, pero el
 * base64 no se vuelve a subir. Devuelve además cuántos bytes de imagen se
 * transmitieron de verdad en esta llamada, para telemetría honesta.
 */
type RespuestaConCierre = {
  candidates?: Array<{ finishReason?: string }>;
  promptFeedback?: { blockReason?: string };
};

/** Why the response ended (Plan A §A0.1): first candidate's `finishReason` and
 * the prompt `blockReason`, only when present and non-empty. */
export function extraerCierreGemini(respuesta: RespuestaConCierre | undefined): Pick<TurnoChat, "finishReason" | "blockReason"> {
  const finishReason = respuesta?.candidates?.[0]?.finishReason;
  const blockReason = respuesta?.promptFeedback?.blockReason;
  return {
    ...(typeof finishReason === "string" && finishReason ? { finishReason } : {}),
    ...(typeof blockReason === "string" && blockReason ? { blockReason } : {}),
  };
}

const NIVELES_PENSAMIENTO_TELEMETRIA = new Set(["minimal", "low", "medium", "high"]);

/** Effective thinking level as `ai_call_log.thinking_level` accepts it: the
 * SDK enum in lowercase, or `default` when none (or an unspecified one) is sent. */
export function nivelPensamientoTelemetria(nivel: ThinkingLevel | undefined): string {
  const valor = String(nivel ?? "").toLowerCase();
  return NIVELES_PENSAMIENTO_TELEMETRIA.has(valor) ? valor : "default";
}

export function historialAContents(
  historial: Mensaje[],
  imagenesEnviadas: WeakSet<ImagenAdjunta>,
): { contents: Content[]; bytesImagenEnviados: number } {
  const contents: Content[] = [];
  let bytesImagenEnviados = 0;

  for (const m of historial) {
    if (m.rol === "usuario") {
      // Cada imagen queda pegada a su ID semántico. El modelo no ve EXIF/XMP
      // de forma fiable; esta etiqueta multimodal es el metadato que sí llega
      // al contexto y permite enlazarla con un JSON por el mismo ID.
      const parts: Part[] = [];
      for (const img of m.imagenes ?? []) {
        if (img.id) {
          parts.push({
            text: `[IMAGEN_ID=${img.id}]${img.descripcion ? ` ${img.descripcion}` : ""}`,
          });
        }
        if (imagenesEnviadas.has(img)) continue;
        parts.push({ inlineData: { mimeType: img.mime, data: img.base64 } });
        imagenesEnviadas.add(img);
        bytesImagenEnviados += bytesDeBase64(img.base64);
      }
      parts.push({ text: m.texto });
      contents.push({ role: "user", parts });
    } else if (m.rol === "asistente" && "texto" in m) {
      contents.push({ role: "model", parts: [{ text: m.texto }] });
    } else if (m.rol === "asistente" && "llamadas" in m) {
      const parts: Part[] = m.llamadas.map((l) => ({
        functionCall: { name: l.nombre, args: l.args, ...(l.id ? { id: l.id } : {}) },
        // Requerido por los modelos "thinking" de Gemini en llamadas de función
        // multi-turno: sin esto, la API rechaza el turno siguiente con
        // INVALID_ARGUMENT ("missing thought_signature").
        ...(typeof l.meta?.thoughtSignature === "string"
          ? { thoughtSignature: l.meta.thoughtSignature }
          : {}),
      }));
      contents.push({ role: "model", parts });
    } else if (m.rol === "herramienta") {
      const parte: Part = {
        functionResponse: {
          name: m.nombre,
          response: m.resultado as Record<string, unknown>,
          ...(m.llamadaId ? { id: m.llamadaId } : {}),
        },
      };
      const ultimo = contents[contents.length - 1];
      if (ultimo?.role === "user" && ultimo.parts?.every((p) => "functionResponse" in p)) {
        ultimo.parts.push(parte);
      } else {
        contents.push({ role: "user", parts: [parte] });
      }
    }
  }

  return { contents, bytesImagenEnviados };
}

function extraerLlamadas(partes: Part[]): LlamadaHerramienta[] {
  return partes
    .filter((parte): parte is Part & { functionCall: NonNullable<Part["functionCall"]> } =>
      Boolean(parte.functionCall?.name),
    )
    .map((parte) => ({
      id: parte.functionCall.id,
      nombre: parte.functionCall.name!,
      args: parte.functionCall.args ?? {},
      meta: parte.thoughtSignature ? { thoughtSignature: parte.thoughtSignature } : undefined,
    }));
}

/**
 * Prefijo estable del mensaje de `ErrorIA` cuando el proveedor rechaza una
 * imagen adjunta (400 INVALID_ARGUMENT: corrupta, truncada, formato que no
 * decodifica). `CausaFallo` no tiene una causa de "entrada inválida"; el
 * prefijo permite a los consumidores traducirlo a un error de adjunto no
 * reintentable sin depender del texto del proveedor.
 */
export const PREFIJO_IMAGEN_RECHAZADA = "AI_IMAGE_REJECTED";

/** Un 400 que habla de la configuración de la petición no es culpa de la imagen. */
const RECHAZO_DE_CONFIGURACION = /function|tool|schema|thought_signature|system_instruction|generation_?config|max_output_tokens|temperature|api key/;

/**
 * `ApiError.status` es el status HTTP real que expone @google/genai; se usa
 * como señal primaria y el substring del mensaje queda de respaldo para
 * errores que no traen status (red, abort por timeout local).
 *
 * `conImagenes`: la petición transmitió bytes de imagen. Un 400
 * INVALID_ARGUMENT en esa petición que no habla de herramientas ni de
 * configuración es la imagen rechazada: reintentar no cambia nada.
 */
export function categorizarError(error: unknown, conImagenes = false): ErrorIA {
  if (error instanceof ErrorIA) return error;
  const mensaje = error instanceof Error ? error.message : "Error desconocido";
  const status = error instanceof ApiError ? error.status : undefined;
  const m = mensaje.toLowerCase();

  if (status === 401 || status === 403 || m.includes("api key") || m.includes("api_key") || m.includes("permission"))
    return new ErrorIA("sin_llave", "gemini", mensaje, false);
  if (status === 429 || m.includes("quota") || m.includes("rate") || m.includes("429"))
    return new ErrorIA("cuota", "gemini", mensaje, true);
  if (m.includes("safety") || m.includes("blocked") || m.includes("filtered"))
    return new ErrorIA("filtrado", "gemini", mensaje, false);
  if (status === 504 || m.includes("timeout") || m.includes("deadline"))
    return new ErrorIA("timeout", "gemini", mensaje, true);
  if (status !== undefined && status >= 500) return new ErrorIA("desconocido", "gemini", mensaje, true);
  const argumentoInvalido = status === 400 || m.includes("invalid_argument");
  if (conImagenes && argumentoInvalido && !RECHAZO_DE_CONFIGURACION.test(m)) {
    return new ErrorIA("desconocido", "gemini", `${PREFIJO_IMAGEN_RECHAZADA}: ${mensaje}`, false);
  }
  return new ErrorIA("desconocido", "gemini", mensaje, true);
}

/**
 * Adaptador `ChatPort` para Gemini. `apiKey`/`modelo` son opcionales — si no
 * se dan, caen a `GEMINI_API_KEY`/`GEMINI_CHAT_MODEL` (mismo comportamiento
 * que tenía este adaptador dentro de demo-decoracion, donde nunca se pasaban
 * explícitos). `thinkingLevel` no se envía por defecto — comportamiento del
 * modelo tal cual, sin bajar el razonamiento salvo que el consumidor lo pida.
 */
export function crearChatGemini(opts?: { apiKey?: string; modelo?: string; thinkingLevel?: ThinkingLevel }): ChatPort {
  const apiKey = opts?.apiKey ?? process.env.GEMINI_API_KEY;
  const modelo = opts?.modelo ?? MODELO_POR_DEFECTO;
  const thinkingConfig = opts?.thinkingLevel !== undefined ? { thinkingLevel: opts.thinkingLevel } : undefined;

  // Fase 3.6: antes se creaba un GoogleGenAI nuevo (y su agente HTTP
  // subyacente) en CADA llamada a turno()/turnoStream() — es decir, una
  // instancia por vuelta del tool loop, no por request. apiKey es fijo
  // para toda la vida de este ChatPort (capturado arriba al construirlo),
  // así que basta con crear el cliente una sola vez aquí.
  const instanciaCliente = apiKey ? new GoogleGenAI({ apiKey }) : null;
  function cliente(): GoogleGenAI | null {
    return instanciaCliente;
  }

  // Vive por instancia de ChatPort — creada una vez por request (ver
  // `chatDe()`), así que sobrevive exactamente las hasta 10 vueltas de una
  // ejecución del tool loop y se descarta con ella. No hay estado compartido
  // entre requests ni entre conversaciones distintas.
  const imagenesEnviadas = new WeakSet<ImagenAdjunta>();

  return {
    id: "gemini",
    modelo,
    thinkingLevel: nivelPensamientoTelemetria(opts?.thinkingLevel),

    async turno(p: PeticionChat): Promise<TurnoChat> {
      const client = cliente();
      if (!client) throw new ErrorIA("sin_llave", "gemini", "No hay GEMINI_API_KEY configurada.", false);

      const { contents, bytesImagenEnviados } = historialAContents(p.historial, imagenesEnviadas);
      try {
        const respuesta = await conReintento(
          () =>
            client.models.generateContent({
              model: modelo,
              contents,
              config: {
                systemInstruction: p.sistema,
                abortSignal: p.signal,
                ...(p.temperatura !== undefined ? { temperature: p.temperatura } : {}),
                ...(p.maxTokens !== undefined ? { maxOutputTokens: p.maxTokens } : {}),
                tools: p.herramientas.length
                  ? [{ functionDeclarations: p.herramientas.map(herramientaADeclaracion) }]
                  : undefined,
                ...(thinkingConfig ? { thinkingConfig } : {}),
              },
            }),
          { esReintentable: (error) => categorizarError(error, bytesImagenEnviados > 0).reintentable, signal: p.signal },
        );

        const partes = respuesta.candidates?.[0]?.content?.parts ?? [];
        return {
          texto: respuesta.text ?? "",
          llamadas: extraerLlamadas(partes),
          uso: extraerUsoGemini(respuesta.usageMetadata),
          modelo,
          bytesImagenEnviados,
          ...extraerCierreGemini(respuesta),
        };
      } catch (error) {
        throw categorizarError(error, bytesImagenEnviados > 0);
      }
    },

    async *turnoStream(p: PeticionChat): AsyncIterable<FragmentoChat> {
      const client = cliente();
      if (!client) throw new ErrorIA("sin_llave", "gemini", "No hay GEMINI_API_KEY configurada.", false);

      const { contents, bytesImagenEnviados } = historialAContents(p.historial, imagenesEnviadas);
      try {
        // Reintento SOLO en la apertura del stream (aún no salió ningún byte
        // al cliente). Un fallo DESPUÉS del primer chunk nunca se reintenta
        // aquí — eso duplicaría texto ya emitido; el consumidor (el motor de
        // conversación, o el propio caller) decide cómo mostrar ese error.
        const stream = await conReintento(
          () =>
            client.models.generateContentStream({
              model: modelo,
              contents,
              config: {
                systemInstruction: p.sistema,
                abortSignal: p.signal,
                ...(p.temperatura !== undefined ? { temperature: p.temperatura } : {}),
                ...(p.maxTokens !== undefined ? { maxOutputTokens: p.maxTokens } : {}),
                tools: p.herramientas.length
                  ? [{ functionDeclarations: p.herramientas.map(herramientaADeclaracion) }]
                  : undefined,
                ...(thinkingConfig ? { thinkingConfig } : {}),
              },
            }),
          { esReintentable: (error) => categorizarError(error, bytesImagenEnviados > 0).reintentable, signal: p.signal },
        );

        let texto = "";
        // Si el modelo llama a más de una herramienta en el mismo turno,
        // cada functionCall puede llegar en un chunk de streaming distinto.
        // Se acumulan por nombre+args (no se sobreescribe el array completo
        // en cada chunk) para no perder una llamada anterior ni su
        // thoughtSignature — ese fue exactamente el bug: al sobreescribir,
        // Gemini rechazaba el turno siguiente por "missing thought_signature"
        // en la llamada que quedó pisada.
        const llamadasPorClave = new Map<string, LlamadaHerramienta>();
        let uso: TurnoChat["uso"] = extraerUsoGemini(undefined);
        let cierre: Pick<TurnoChat, "finishReason" | "blockReason"> = {};

        for await (const chunk of stream) {
          const delta = chunk.text ?? "";
          if (delta) {
            texto += delta;
            yield { tipo: "texto", delta };
          }
          const partes = chunk.candidates?.[0]?.content?.parts ?? [];
          for (const llamada of extraerLlamadas(partes)) {
            const clave = llamada.id ?? `${llamada.nombre}:${JSON.stringify(llamada.args)}`;
            llamadasPorClave.set(clave, llamada);
          }
          if (chunk.usageMetadata) {
            uso = extraerUsoGemini(chunk.usageMetadata);
          }
          // The reason arrives on the last chunk; keep the latest one seen.
          cierre = { ...cierre, ...extraerCierreGemini(chunk) };
        }

        yield { tipo: "fin", texto, llamadas: [...llamadasPorClave.values()], uso, modelo, bytesImagenEnviados, ...cierre };
      } catch (error) {
        throw categorizarError(error, bytesImagenEnviados > 0);
      }
    },
  };
}
